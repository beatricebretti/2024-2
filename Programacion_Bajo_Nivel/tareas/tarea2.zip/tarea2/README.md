# Tarea 2
Beatrice Valdes Bretti

se simula el cruce de vehículos en un ferry que opera entre dos riberas. La simulación genera vehículos aleatorios que llegan a las riberas en diferentes horarios y cantidades, y el ferry transporta estos vehículos de acuerdo con un horario establecido.

## Compilación y Ejecución

- `make run` para compilar y ejecutar el programa.
- `make all` para compilar todos los archivos y generar el ejecutable.
- `make clean` para eliminar los archivos objeto y el ejecutable.
- `make ferry` para compilar y crear el ejecutable ferry.
- `make principal.o` para compilar el archivo fuente principal.c.
- `make user.o` para compilar el archivo fuente user.c.

