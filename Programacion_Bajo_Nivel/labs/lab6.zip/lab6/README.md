# Laboratorio 6 Programación de Bajo Nivel  
Beatrice Valdés Bretti

## Compilación y Ejecución
- `make run` para compilar y ejecutar el programa.
- `make all` para compilar todos los archivos y generar el ejecutable.
- `make clean` para eliminar los archivos objeto y ejecutables.

## Funcionamiento
- El programa solicita ingresar al menos dos usuarios con email y contraseña.
- Después del segundo usuario, se puede elegir si continuar agregando más usuarios.
