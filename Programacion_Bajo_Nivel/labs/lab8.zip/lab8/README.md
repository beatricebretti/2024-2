# Laboratorio 8
Beatrice Valdes Bretti

# Compilación y Ejecución
- `make run` para compilar y ejecutar todo 
- `make all` para compilar y todo y eliminar previos ejecutables
- `make clean` para eliminar los ejecutables
- `make main` para compilar todo y generar ejecutables
- `make vehiculo/sedan/suv/deportivo/furgon.o` compilar la clase y su header respectivo