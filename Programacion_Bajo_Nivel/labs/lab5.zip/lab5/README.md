# Laboratorio 5 Programación de Bajo Nivel
Beatrice Valdés Bretti 

## Compilación y Ejecución
- `make run` para compilar y ejecutar todo 
- `make all` para compilar y ejecutar todo y eliminar previos ejecutables
- `make clean` para eliminar los ejecutables
- `make full` para compilar todos los archivos
- `make func.o` para compilar los archivos de las funciones
- `make princ.o` para compilar el programa principal

## Funcionamiento
- Se puede utilizar el programa de distintas formas, aleatorio, ingresando numeros manualmente o con fgets.