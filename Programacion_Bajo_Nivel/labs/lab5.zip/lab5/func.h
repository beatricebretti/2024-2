int mayorLista(int *lista, int largo);
int sumaLista(int *lista, int largo);