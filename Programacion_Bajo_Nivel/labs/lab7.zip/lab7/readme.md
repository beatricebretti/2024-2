# Laboratorio 7 Programación de Bajo Nivel  
Beatrice Valdés Bretti

## Compilación y Ejecución
- `make run` para compilar y ejecutar el programa.
- `make all` para compilar todos los archivos y generar el ejecutable, además de limpiar.
- `make clean` para eliminar los archivos objeto y ejecutables.

